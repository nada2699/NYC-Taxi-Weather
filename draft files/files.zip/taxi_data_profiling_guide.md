# NYC Yellow Taxi — Data Profiling & Documentation Guide

Use this as the backbone for reorganizing the discovery notebook. Each section = one notebook section. For each column group: **(1) what to check → (2) summary stats to compute → (3) a documentation sentence to write**, since that sentence is what actually carries into your Transformation-phase design decisions.

---

## 1. VendorID
**Check:**
- Extract unique values, confirm against data dictionary (1=CMT, 2=Curb Mobility, 6=Myle, 7=Helix).

**Summarize:**
- Trip count & % share per vendor.
- `total_amount` stats per vendor (mean, min, max, % negative).
- % of each vendor's rows falling in the null cluster (see §3).

**Documentation sentence (already known):**
> All 4 documented VendorIDs are present. Vendor 2 dominates volume (2.72M / 78%); Vendors 6 and 7 are minor (489 / 1,206 trips). VendorID 1's `total_amount` field has a distinct calculation rule (see §7).

---

## 2. Timestamps & Duration
**Check:**
- Confirm timestamps are naive/local throughout (no stray tz-aware rows) — done, confirmed clean.
- Negative duration (`dropoff < pickup`) count.
- Extreme duration (>4h) count.
- Cross-check extreme-duration rows against same-location outlier segment (§8).

**Summarize:**
- Duration distribution (min/max/percentiles).
- Count & vendor breakdown of negative-duration rows.

**Documentation sentence (already known):**
> Duration ranges from -36 days to +3 days 21h, both clearly erroneous. Negative-duration and multi-day rows require exclusion or correction; at least one multi-day case pairs with an exact-reversal duplicate (see §9).

---

## 3. The Null Cluster (`passenger_count`, `RatecodeID`, `store_and_fwd_flag`, `congestion_surcharge`, `Airport_fee`)
**Check:**
- Confirm all 5 columns share the identical null count (540,149) — done.
- Map null rows to VendorID.

**Summarize:**
- VendorID breakdown: Vendor 2 (451,456) + Vendor 1 (88,204) + Vendor 6 (489, 100% of Vendor 6) = 540,149.
- Cross-reference: what % of *other* quality issues (mta_tax anomalies, speed outliers) fall inside this cluster.

**Documentation sentence (already known):**
> The null cluster is a defined, explainable segment (not random) tracing to specific vendor feeds — entirely Vendor 6, plus partial Vendor 1/2. This segment also disproportionately overlaps with other quality issues (69/77 mta_tax anomalies, 170/348 speed outliers), making it a broader low-confidence flag, not just a missing-fields issue.

---

## 4. RatecodeID
**Check:**
- Count of `99` (documented "Null/unknown").
- Distribution by vendor.

**Summarize:**
- `RatecodeID = 99`: 41,963 rows.
- Vendor 6 uses only `nan`; Vendor 7 only uses [1, 2, 5] — narrower behavior than Vendors 1/2.

**Documentation sentence (already known):**
> RatecodeID 99 (41,963 rows) is a documented placeholder, not an error. Vendor coverage of rate codes varies meaningfully (Vendor 6: none populated; Vendor 7: only 3 of 7 codes used).

---

## 5. Location Fields (`PULocationID`, `DOLocationID`)
**Check (some still outstanding):**
- [ ] Validate every ID against the zone lookup table (not yet done — needed before this can be marked complete).
- [ ] Count trips landing in zones 264/265 (TLC's "Unknown"/"N/A" placeholders).
- Same pickup=dropoff trips combined with outlier flags (done — 425 records).

**Documentation sentence (already known + pending):**
> 425 trips combine same-location pickup/dropoff with an extreme value in speed, fare/mile, distance, or total_amount — high-confidence error candidates. Zone-lookup join validation is still outstanding.

---

## 6. payment_type
**Check:**
- Distribution across documented codes (0–6).
- `tip_amount > 0` where `payment_type != 1` (documented violation, since tips should only auto-populate for credit card).

**Summarize:**
- Vendor breakdown of the violation.
- Split by resulting `total_amount` sign (positive vs negative) — negative-skewed pattern suggests correction records.

**Documentation sentence (already known):**
> Tips appear under payment types 0, 2, 3, and 4 despite documentation limiting auto-populated tips to type 1. The cash (type 2) case skews heavily negative-total (164/189), consistent with correction/reversal records rather than genuine cash tips.

---

## 7. Fare Component Columns & `total_amount` Reconciliation
**Check:**
- Negative-value counts per column (fare_amount, extra, mta_tax, tip_amount, tolls_amount, improvement_surcharge, congestion_surcharge, Airport_fee, cbd_congestion_fee) — done for all.
- `mta_tax` non-standard values (legal standard is $0.50 / $0 / -$0.50 only) — done, root-caused.
- `fare_sum` (component sum, `skipna=True`) vs `total_amount` — done, root-caused into 3 patterns.

**Summarize (already known — this is your strongest finding):**
- **mta_tax anomaly:** 77 rows, isolated to Vendor 1, 69/77 inside the null cluster; no rate-code business logic explains it → vendor-side formatting error.
- **"notsummed" pattern (683,315 rows, 100% Vendor 1):** `total_amount` excludes `congestion_surcharge`, `Airport_fee`, and `cbd_congestion_fee` entirely. A systematic, vendor-specific calculation rule/bug — correctable via formula.
- **"doublesummed" pattern (mixed vendors):** those same three fees are counted *twice* in `total_amount`.
- **Remaining unexplained mismatches:** quantify what's left after removing both patterns above.

**Documentation sentence (already known):**
> `total_amount` inconsistencies are not random noise — 683,315 rows (100% Vendor 1) follow a specific, correctable rule where three fee columns are excluded from `total_amount`. A separate double-counting pattern affects a mix of vendors. Both are programmatically correctable in Transformation rather than requiring exclusion.

---

## 8. Outlier Bounds (`total_amount`, `trip_distance`, `speed_mph`, `fare_mile`)
**Check:**
- 99.99th percentile bounds set for all four — done.
- Compound filter (same-location + any bound exceeded) — done, 425 records.
- Known artifact: `fare_mile` unstable for very short trips (near-zero denominator) — needs a minimum-distance floor before applying.

**Summarize:**
- Document the actual percentile cutoff values used for each metric.
- Note example rows (22h same-location trip; 9.2mi/21sec trip) as concrete evidence for the write-up.

**Documentation sentence (to finalize once floor is applied):**
> Outlier bounds set at the 99.99th percentile for total_amount, trip_distance, speed_mph, and fare_mile. fare_mile is only evaluated for trips ≥0.5 miles to avoid ratio instability at near-zero distances. Rows are flagged (not dropped) via boolean outlier columns, preserving auditability.

---

## 9. Duplicates & Corrections
**Check:**
- "Seemed duplicate" (VendorID + pickup + dropoff only) vs "true duplicate" (10-column match) — done, both computed.
- `group_total` (sum of `total_amount` within duplicate groups) — done; many groups sum to exactly 0.
- `payment_type` breakdown of duplicate groups — done.

**Documentation sentence (already known):**
> Most "duplicate" trips are not genuine duplicates but paired reversal/correction records — many duplicate groups sum to $0 total_amount. Disputes (payment_type 4) account for the largest share (59,444), supporting a correction-driven explanation rather than duplicated service records.

---

## 10. Cross-Cutting Summary (write this last)
Pull together one paragraph per major theme for your final report:
1. **Null cluster** = defined, vendor-traceable, low-confidence segment.
2. **`total_amount` mismatches** = two explainable, correctable vendor-specific rules + a smaller unexplained residual.
3. **Duplicates** = mostly corrections/reversals, not true duplication.
4. **Outliers** = rare but real, best caught by compound signals (location + metric) rather than single-column thresholds.

---

## Still Outstanding (from the original checklist)
- [ ] Zone lookup join validation (PULocationID/DOLocationID completeness against `dim_zone`)
- [ ] Quantify `remaining_df` (unexplained total_amount mismatches after both known patterns removed)
- [ ] Apply the `fare_mile` minimum-distance floor and re-run outlier bound calculations
- [ ] Weather-side: confirm hour-alignment join rule (floor to hour) tested against real taxi timestamps
