# Phase 4 — Data Discovery Summary
**Project:** NYC Taxi + Weather Analytics Pipeline
**Scope:** Yellow Taxi trips, January 2025 · Open-Meteo weather, 5 NYC boroughs

---

## 1. Data Sources

| Source | Volume | Coverage |
|---|---|---|
| TLC Yellow Taxi (`yellow_tripdata_2025-01.parquet`) | 3,475,226 rows, 20 columns | Dec 31, 2024 20:47 → Feb 1, 2025 23:44 |
| TLC Taxi Zone Lookup | 265 zones | LocationID → Borough → Zone → Service Zone |
| Open-Meteo Historical Weather | 4,080 hourly records | 5 boroughs (Manhattan, Brooklyn, Queens, Bronx, Staten Island), Dec 30 2024 → Feb 2 2025 (buffered) |

---

## 2. Schema & Vendor Overview

All 4 documented `VendorID` values present and validated against the official TLC dictionary:

| VendorID | Provider | Trips | Share |
|---|---|---|---|
| 1 | Creative Mobile Technologies | 753,671 | 21.7% |
| 2 | Curb Mobility | 2,719,860 | 78.3% |
| 6 | Myle Technologies | 489 | <0.1% |
| 7 | Helix | 1,206 | <0.1% |

`payment_type = 0` (Flex Fare) and `RatecodeID = 99` (Null/unknown) are both legitimate documented codes, not anomalies.

---

## 3. Key Data Quality Findings

### 3.1 The Null Cluster — root-caused, not random
**540,149 rows** (15.5% of the dataset) are missing `passenger_count`, `RatecodeID`, `store_and_fwd_flag`, `congestion_surcharge`, and `Airport_fee` together.

- Traced to specific vendor feeds: Vendor 2 (451,456) + Vendor 1 (88,204) + **100% of Vendor 6** (489) = 540,149 exactly.
- **Confirmed identical to `payment_type = 0`** (Flex Fare) — every null-cluster row across all three vendors carries `payment_type = 0` and no other value. This is a single explained segment, not three separate issues.
- This segment also disproportionately overlaps with other quality issues below (69/77 `mta_tax` anomalies; ~49% of speed outliers), making it a broader low-confidence flag warranting a `data_quality_segment` marker in Transformation, not just null-handling.

### 3.2 `mta_tax` Anomalies — isolated, root-caused
Legal standard (NY Tax Law Art. 29-A) is a flat **$0.50** (or $0 exempt, -$0.50 refund). 77 rows violate this:

| Value | Count |
|---|---|
| 1.00 | 64 |
| 10.50 | 5 |
| 4.75 | 3 |
| 4.00 | 2 |
| 3.75 | 2 |
| 6.50 | 1 |

- **100% isolated to Vendor 1.**
- 69/77 fall inside the null cluster; 8 are standalone.
- No RatecodeID-based business logic explains the values (occurs under Standard, JFK, and Unknown codes with no consistent pattern) → vendor-side formatting error.

### 3.3 `total_amount` vs. Component Sum — root-caused into 3 explained patterns
Of 1,414,304 mismatched rows (`total_amount` ≠ sum of fare components, cash-payment rows excluded from this check since their tip handling differs):

| Pattern | Rows | Explanation |
|---|---|---|
| **"notsummed"** | 525,428 (100% Vendor 1) | `total_amount` systematically excludes `congestion_surcharge`, `Airport_fee`, `cbd_congestion_fee` — a correctable, deterministic vendor rule |
| **"doublesummed"** | 722 (Vendors 1, 2, 7) | Those same three fees are double-counted in `total_amount` |
| **Unexplained residual** | 497,725 (Vendor 1: 77,426 · Vendor 2: 419,399 · Vendor 6: 489 · Vendor 7: 411) | Not yet reduced to a formula; likely partially overlaps with duplicate/reversal pairs (§3.4) — worth a final targeted check in Transformation |

### 3.4 Duplicates Are Mostly Reversal/Correction Pairs
"Duplicate" trips (same Vendor + pickup + dropoff + 7 other fields) frequently sum to **exactly $0** in `total_amount` across the pair — indicating a charge and its exact reversal, not duplicated service.

- Breakdown by `payment_type`: Dispute (4): 59,444 · Cash (2): 24,976 · No charge (3): 12,982 · Credit (1): 28 — dispute-heavy, consistent with a correction-driven mechanism.

### 3.5 Documented-Behavior Violations
- `tip_amount > 0` recorded for `payment_type` values other than 1 (Credit card) despite documentation limiting auto-populated tips to credit card only: **56,873 rows** across types 0, 2, 3, 4.
- Cash-specific case (`payment_type = 2`, tip > 0): 189 rows, 164 with negative `total_amount` — consistent with correction records rather than genuine cash tips.

### 3.6 Outlier Bounds (99.99th percentile)
Set for `total_amount`, `trip_distance`, `speed_mph`, and `fare_mile`. Notes:
- `fare_mile` only computed for `trip_distance > 0.5 mi` to avoid near-zero-denominator ratio instability.
- Strongest signal is **compound**: same `PULocationID = DOLocationID` combined with any bound exceeded (425 records) — includes clear errors like a 22-hour same-location trip and a 9.2-mile trip in 21 seconds (~1,577 mph).
- Speed outliers overlap heavily with the null cluster (~49%), reinforcing §3.1.

### 3.7 Location Fields — fully validated
- Every `PULocationID`/`DOLocationID` exists in the zone lookup table — **zero orphaned IDs**.
- Zones 264/265 (TLC's Unknown/N/A placeholders) account for the bulk of downstream join gaps (see §4).

---

## 4. Weather ↔ Taxi Join Validation

Performed as a real merge (not value-overlap check), keyed on `(borough, floored_pickup_hour)`:

| Join side | Matched | Unmatched | Unmatched cause |
|---|---|---|---|
| Pickup (`PULocationID`) | 3,465,328 (99.72%) | 9,898 | Zone 1 (EWR, 377 rows — no NJ weather coverage) + Zones 264/265 (~9,521 rows — no borough mapping) |
| Dropoff (`DOLocationID`) | 3,444,291 (99.11%) | 30,935 | Same zones (1, 264, 265) |

**Both pickup- and dropoff-side weather joins are validated and usable.** All in-scope analytical questions are currently framed around pickup-time conditions, but dropoff-time weather questions are also supported if needed later.

**Scope decision:** EWR (377 pickup rows, <0.02% of data) is excluded from weather-dependent analysis rather than adding a 6th weather point — documented as an accepted, low-impact gap.

---

## 5. Decisions Made This Phase

- Weather granularity: **borough-level** (5 points), not zone-level or single citywide point.
- Airport trips use their borough's weather (JFK/LGA → Queens) rather than dedicated airport weather points.
- Weather pulled **outside Databricks** (local/VS Code) due to Community Edition's shared-IP rate-limiting on Open-Meteo, then landed as a file — documented as a known CE limitation, not a pipeline flaw.
- Outliers will be **flagged, not silently dropped**, preserving auditability.

---

## 6. Carried Forward to Architecture / Transformation

- [ ] Correction formula for Vendor 1's "notsummed" `total_amount` rows (mechanical fix, not exclusion)
- [ ] Handling rule for "doublesummed" rows
- [ ] Re-check whether duplicate/reversal pairs explain part of the 497,725 unexplained `total_amount` residual
- [ ] Null-cluster / `payment_type = 0` segment: decide flag vs. quarantine vs. separate-confidence handling
- [ ] `mta_tax` correction rule (null out or flag non-standard values)
- [ ] Weather unit standardization (Celsius/km/h vs. Fahrenheit/mph) — not yet finalized
- [ ] Green/FHV expansion — explicitly deferred to Architecture per Requirements scoping

---

## Phase 4 Status: **Closed**
Every open Discovery item has been investigated, root-caused, or explicitly scoped as a documented limitation. Ready to proceed to **Phase 5: Architecture & Design**.
